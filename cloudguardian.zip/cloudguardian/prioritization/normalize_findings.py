"""
CloudGuardian - Week 2: Normalize Prowler findings into a consolidated schema.

Prowler's native output (json-ocsf or json-asff) already has most of what we
need; this script flattens it into a simple flat CSV/JSON that's easy to feed
into the prioritization model and the LLM step.

Usage:
    python3 normalize_findings.py --input ../findings/post-misconfig/*.json \
                                   --output findings_normalized.csv
"""

import argparse
import glob
import json
import csv
import sys


NORMALIZED_FIELDS = [
    "finding_id",
    "check_id",
    "title",
    "severity",
    "status",          # PASS / FAIL
    "resource_type",
    "resource_id",
    "region",
    "category",         # networking / iam / storage / encryption / logging
    "remediation_raw",  # Prowler's own remediation text, if present
]

# Map Prowler check-id substrings to our 5 project categories, for consistent
# reporting even if Prowler's own metadata categorization differs.
CATEGORY_KEYWORDS = {
    "networking": ["securitygroup", "vpc", "flow_log", "publicly_accessible", "port_22", "port_3306"],
    "iam": ["iam_", "access_key", "administratoraccess", "policy"],
    "storage": ["s3_bucket", "public_access_block"],
    "encryption": ["encrypt", "kms"],
    "logging": ["cloudtrail", "flow_log", "logging"],
}


def guess_category(check_id: str) -> str:
    check_id_lower = check_id.lower()
    for category, keywords in CATEGORY_KEYWORDS.items():
        if any(k in check_id_lower for k in keywords):
            return category
    return "uncategorized"


def load_prowler_ocsf(filepath: str):
    """Prowler's json-ocsf output is a list of finding objects."""
    with open(filepath, "r") as f:
        data = json.load(f)

    # Prowler OCSF output can be a top-level list or wrapped; handle both.
    findings = data if isinstance(data, list) else data.get("findings", [])

    normalized = []
    for finding in findings:
        check_id = finding.get("metadata", {}).get("event_code") or finding.get("check_id", "unknown")
        normalized.append({
            "finding_id": finding.get("finding_info", {}).get("uid", finding.get("uid", "")),
            "check_id": check_id,
            "title": finding.get("finding_info", {}).get("title", finding.get("check_title", "")),
            "severity": finding.get("severity", "unknown"),
            "status": finding.get("status", finding.get("status_code", "unknown")),
            "resource_type": finding.get("resources", [{}])[0].get("type", "unknown"),
            "resource_id": finding.get("resources", [{}])[0].get("uid", "unknown"),
            "region": finding.get("resources", [{}])[0].get("region", "unknown"),
            "category": guess_category(check_id),
            "remediation_raw": finding.get("remediation", {}).get("desc", ""),
        })
    return normalized


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", nargs="+", required=True, help="Prowler JSON output file(s)")
    parser.add_argument("--output", default="findings_normalized.csv")
    args = parser.parse_args()

    all_findings = []
    input_files = []
    for pattern in args.input:
        input_files.extend(glob.glob(pattern))

    if not input_files:
        print(f"No files matched: {args.input}", file=sys.stderr)
        sys.exit(1)

    for filepath in input_files:
        try:
            all_findings.extend(load_prowler_ocsf(filepath))
        except Exception as e:
            print(f"WARNING: could not parse {filepath}: {e}", file=sys.stderr)

    with open(args.output, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=NORMALIZED_FIELDS)
        writer.writeheader()
        writer.writerows(all_findings)

    # Also emit JSON for the prioritization/LLM steps that prefer it
    json_output = args.output.rsplit(".", 1)[0] + ".json"
    with open(json_output, "w") as f:
        json.dump(all_findings, f, indent=2)

    print(f"Wrote {len(all_findings)} normalized findings to {args.output} and {json_output}")


if __name__ == "__main__":
    main()
