# LLM Remediation Prompt Template

Use this exact template (or your close variant) for every finding, and **disclose it verbatim
in your report** per the brief's Section 12 requirement ("Any use of GenAI/LLMs must be
disclosed... which model, what it was used for, how outputs were verified").

## Privacy note before you send anything to an LLM API

Never paste real credentials, account IDs, customer data, or full IAM principal ARNs into
the prompt. Redact resource identifiers (e.g. replace `arn:aws:iam::123456789012:role/...`
with `arn:aws:iam::<ACCOUNT_ID>:role/web-instance-role`) before sending.

## Prompt template

```
System: You are a cloud security assistant helping a student write a plain-English
explanation of a CSPM finding for a compliance report. Do not invent facts not present
in the finding data below. If information is missing, say so explicitly rather than
guessing. Keep the explanation to 2 lines maximum.

Finding data (from Prowler, redacted):
- Check ID: {check_id}
- Title: {title}
- Severity: {severity}
- Resource type: {resource_type}
- Category: {category}

Task: Write a 2-line plain-English explanation of (1) what is wrong and (2) why it
matters, suitable for a non-technical compliance reviewer.
```

## Verification workflow (mandatory — this is 15% of your rubric)

For every LLM-generated explanation:
1. Check it against the raw Prowler finding — does it accurately describe what the check
   actually tested? Flag and correct any hallucinated detail (e.g. LLM inventing a CVE
   number that wasn't in the input).
2. Record a verification note per finding: `Verified against raw finding — no discrepancy`
   or `Corrected: LLM claimed X, raw finding shows Y`.
3. Never let an unverified LLM explanation go into the final report as-is.

## Example (fill in with your own real finding after Week 2 scans)

| Check ID | Severity | Raw Prowler description (paraphrase, not exact scanner text) | LLM 2-line explanation | Verification note |
|---|---|---|---|---|
| `ec2_securitygroup_allow_ingress_from_internet_to_port_22` | High | Reports a security group permitting inbound SSH from any IP | "Your server accepts remote login attempts from anywhere on the internet. This is one of the most common ways attackers gain initial access." | Verified — matches raw finding, no invented details |
