"""
CloudGuardian - Week 2: Generate plain-English remediation explanations via
the Anthropic API, with a basic verification pass against the raw finding.

Requires: pip3 install anthropic --break-system-packages
Requires: export ANTHROPIC_API_KEY=your_key   (never hardcode it, never commit it)

Usage:
    python3 llm_remediation.py --input findings_prioritized.csv \
                                --output findings_with_explanations.csv \
                                --top-n 15
"""

import argparse
import csv
import os
import sys

try:
    import anthropic
except ImportError:
    print("Run: pip3 install anthropic --break-system-packages", file=sys.stderr)
    sys.exit(1)


PROMPT_TEMPLATE = """You are a cloud security assistant helping a student write a plain-English
explanation of a CSPM finding for a compliance report. Do not invent facts not present
in the finding data below. If information is missing, say so explicitly rather than
guessing. Keep the explanation to 2 lines maximum.

Finding data (from Prowler, redacted):
- Check ID: {check_id}
- Title: {title}
- Severity: {severity}
- Resource type: {resource_type}
- Category: {category}

Task: Write a 2-line plain-English explanation of (1) what is wrong and (2) why it
matters, suitable for a non-technical compliance reviewer."""


def redact(value: str) -> str:
    """Very basic redaction of account IDs from resource identifiers."""
    import re
    return re.sub(r"\d{12}", "<ACCOUNT_ID>", value or "")


def verify_explanation(explanation: str, row: dict) -> str:
    """
    Lightweight verification: flag if the explanation mentions a severity
    word that contradicts the raw finding, or if it's suspiciously long
    (a sign the LLM may be padding with invented detail).
    """
    severity = row.get("severity", "").lower()
    explanation_lower = explanation.lower()

    contradictions = {
        "critical": ["low risk", "minor", "not a concern"],
        "low": ["critical", "severe emergency"],
    }
    for word in contradictions.get(severity, []):
        if word in explanation_lower:
            return f"FLAGGED: explanation says '{word}' but raw severity is '{severity}'"

    if len(explanation.split()) > 60:
        return "FLAGGED: explanation longer than expected for a 2-line summary — review for invented detail"

    return "Verified — consistent with raw finding, no contradiction detected"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", default="findings_with_explanations.csv")
    parser.add_argument("--top-n", type=int, default=15, help="Only explain the top N by priority score (cost control)")
    args = parser.parse_args()

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("Set ANTHROPIC_API_KEY environment variable first.", file=sys.stderr)
        sys.exit(1)

    client = anthropic.Anthropic(api_key=api_key)

    with open(args.input, "r") as f:
        rows = list(csv.DictReader(f))

    fail_rows = [r for r in rows if r.get("status", "").upper() == "FAIL"]
    fail_rows.sort(key=lambda r: -float(r.get("priority_score", 0)))
    target_rows = fail_rows[: args.top_n]

    for row in target_rows:
        prompt = PROMPT_TEMPLATE.format(
            check_id=redact(row.get("check_id", "")),
            title=redact(row.get("title", "")),
            severity=row.get("severity", ""),
            resource_type=row.get("resource_type", ""),
            category=row.get("category", ""),
        )

        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=200,
            messages=[{"role": "user", "content": prompt}],
        )
        explanation = "".join(
            block.text for block in response.content if block.type == "text"
        ).strip()

        row["llm_explanation"] = explanation
        row["verification_note"] = verify_explanation(explanation, row)
        print(f"[{row.get('check_id')}] {explanation}\n  -> {row['verification_note']}\n")

    all_fieldnames = list(rows[0].keys())
    for extra in ("llm_explanation", "verification_note"):
        if extra not in all_fieldnames:
            all_fieldnames.append(extra)

    with open(args.output, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=all_fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"\nWrote {len(rows)} rows ({len(target_rows)} with LLM explanations) to {args.output}")


if __name__ == "__main__":
    main()
