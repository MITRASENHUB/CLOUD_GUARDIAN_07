"""
CloudGuardian - Week 2: Prioritization scoring model.

Score = CVSS_proxy x Exposure x Blast_radius

This is a deliberately simple, explainable model (not a black-box ML model) —
your rubric rewards "justified features, honest evaluation" over complexity.
Document in your report exactly why each weight was chosen.

Usage:
    python3 prioritization_model.py --input findings_normalized.csv \
                                     --output findings_prioritized.csv
"""

import argparse
import csv


# --- Feature 1: CVSS proxy, derived from Prowler's own severity label ---
# Prowler already maps checks to a severity; we convert that to a 0-10 scale
# resembling CVSS base score bands. This is a proxy, not a real CVSS
# calculation - be upfront about that in your report.
SEVERITY_TO_CVSS = {
    "critical": 9.5,
    "high": 7.5,
    "medium": 5.0,
    "low": 2.5,
    "informational": 1.0,
    "unknown": 3.0,
}

# --- Feature 2: Exposure multiplier ---
# Is the resource internet-facing, or only reachable internally?
# We derive this from the category + a few keyword checks on the check_id.
def exposure_score(check_id: str, category: str) -> float:
    check_id_lower = check_id.lower()
    if "internet" in check_id_lower or "public" in check_id_lower or "0.0.0.0" in check_id_lower:
        return 1.0  # directly internet-exposed
    if category in ("networking",):
        return 0.8
    if category in ("storage", "iam"):
        return 0.6
    return 0.3  # e.g. logging gaps are real but not directly "exposed"


# --- Feature 3: Blast radius ---
# How much can a single compromised resource cascade? An over-privileged IAM
# role or admin policy has a much bigger blast radius than, say, a single
# unencrypted log bucket.
BLAST_RADIUS_BY_CATEGORY = {
    "iam": 1.0,
    "networking": 0.8,
    "storage": 0.7,
    "encryption": 0.5,
    "logging": 0.3,
    "uncategorized": 0.4,
}


def compute_priority_score(row: dict) -> float:
    severity = row.get("severity", "unknown").lower()
    cvss = SEVERITY_TO_CVSS.get(severity, 3.0)
    exposure = exposure_score(row.get("check_id", ""), row.get("category", "uncategorized"))
    blast = BLAST_RADIUS_BY_CATEGORY.get(row.get("category", "uncategorized"), 0.4)

    # Normalize to a 0-100 scale for readability in the report.
    raw_score = cvss * exposure * blast
    return round(raw_score * 10, 1)  # cvss max 9.5 * exposure max 1 * blast max 1 * 10 ~= 95-100 ceiling


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", default="findings_prioritized.csv")
    args = parser.parse_args()

    with open(args.input, "r") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    for row in rows:
        row["priority_score"] = compute_priority_score(row)

    # Only re-prioritize FAIL findings — PASS findings don't need action.
    rows.sort(key=lambda r: (r.get("status", "").upper() != "PASS", -float(r["priority_score"])))

    fieldnames = list(rows[0].keys()) if rows else []
    with open(args.output, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"Wrote {len(rows)} prioritized findings to {args.output}")
    print("\nTop 5 by priority score:")
    for row in [r for r in rows if r.get("status", "").upper() == "FAIL"][:5]:
        print(f"  [{row['priority_score']}] {row.get('check_id')} - {row.get('title')}")


if __name__ == "__main__":
    main()
