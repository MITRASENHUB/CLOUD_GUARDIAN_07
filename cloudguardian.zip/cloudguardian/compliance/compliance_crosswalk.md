# Compliance Crosswalk — ISO 27001:2022 Annex A + DPDP Act 2023

Fill in the **Status** column with your actual scan results after Week 1/2.

| Misconfig | ISO 27001 Annex A control | DPDP Act 2023 relevance | Status (after fix) |
|---|---|---|---|
| MC-01 (open SSH) | A.8.20 Networks security | Sec. 8(5) — reasonable security safeguards against unauthorized access | |
| MC-02 (open DB port) | A.8.20 Networks security, A.8.22 Segregation of networks | Sec. 8(5) | |
| MC-03 (admin EC2 role) | A.8.2 Privileged access rights | Sec. 8(5) — safeguards proportionate to risk of processing | |
| MC-04 (S3 public access off) | A.8.10 Information deletion / A.5.14 Information transfer, A.8.24 Use of cryptography (indirectly) | Sec. 8(5), Sec. 8(6) — breach notification obligations if data exposed | |
| MC-05 (public bucket policy) | A.5.15 Access control | Sec. 8(5) | |
| MC-06 (RDS encryption off) | A.8.24 Use of cryptography | Sec. 8(5) — safeguards for personal data at rest | |
| MC-07 (stale IAM key) | A.5.17 Authentication information, A.8.5 Secure authentication | Sec. 8(5) | |
| MC-08 (overly broad IAM policy) | A.8.2 Privileged access rights, A.5.15 Access control | Sec. 8(5) | |
| MC-09 (CloudTrail disabled) | A.8.15 Logging | Sec. 8(6) — need audit trail to detect/report a personal data breach | |
| MC-10 (Flow Logs disabled) | A.8.15 Logging, A.8.16 Monitoring activities | Sec. 8(6) | |
| MC-11 (RDS publicly accessible) | A.8.20 Networks security | Sec. 8(5), Sec. 8(6) | |
| MC-12 (log bucket encryption off) | A.8.24 Use of cryptography | Sec. 8(5) | |

## Notes for your report

- ISO 27001 Annex A control numbers above reference the **2022 revision**. Verify against
  your instructor's expected version if different.
- The DPDP Act 2023 does not prescribe specific technical controls the way ISO 27001 does —
  it requires "reasonable security safeguards" (Section 8(5)) and breach notification duties
  (Section 8(6)). Frame your mapping as "this control helps satisfy the safeguard obligation,"
  not as a direct one-to-one legal mapping — be precise about this distinction in your report,
  since overclaiming legal compliance is something evaluators will probe in the oral defense.
- If your team chose HIPAA or PCI-DSS as your third framework (per the team-scope requirement),
  add equivalent columns here — HIPAA's Security Rule (45 CFR §164.312) and PCI-DSS
  Requirements 1 (network segmentation), 3 (encrypt stored data), and 10 (logging) map onto
  the same 12 misconfigs fairly directly.
