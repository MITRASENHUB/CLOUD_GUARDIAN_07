# CloudGuardian — Misconfiguration Catalogue

12 misconfigurations across Networking, IAM, Storage, Encryption, and Logging.
Each is toggled independently via a boolean in `terraform.tfvars` (see `terraform/variables.tf`).

Fill in the **Evidence** and **Prowler check ID** columns yourselves after you actually run
the scans — do not submit this with placeholder text.

| ID | Category | Owner | What changes | Real-world relevance | Prowler / CIS check (fill in exact ID) | Severity | Evidence (screenshot / scan excerpt) | Revert |
|----|----------|-------|--------------|----------------------|------------------------------------------|----------|----------------------------------------|--------|
| MC-01 | Networking | Person A | SSH (22) opened to 0.0.0.0/0 on web SG | #1 misconfig found by internet scanners within minutes | `ec2_securitygroup_allow_ingress_from_internet_to_port_22` | High | | Set `enable_misconfig_01 = false`, re-apply |
| MC-02 | Networking | Person A | DB port 3306 opened to 0.0.0.0/0 instead of web-tier-only | Breaks tier isolation — DB directly reachable from internet | `ec2_securitygroup_allow_ingress_from_internet_to_port_3306` | Critical | | `enable_misconfig_02 = false` |
| MC-03 | IAM | Person A | AdministratorAccess attached to EC2 web instance role | Classic over-privileged role — app compromise = full account compromise | `iam_role_administratoraccess_policy_attached` (or equivalent) | Critical | | `enable_misconfig_03 = false` |
| MC-04 | Storage | Person B | S3 Public Access Block disabled on app bucket | Root cause of countless real breaches (Capital One and others) | `s3_bucket_level_public_access_block` | Critical | | `enable_misconfig_04 = false` |
| MC-05 | Storage | Person B | Bucket policy allows `s3:GetObject` to `*` | Makes bucket actually publicly readable, not just technically exposed | `s3_bucket_public_read_acl` / policy check | Critical | | `enable_misconfig_05 = false` |
| MC-06 | Encryption | Person B | RDS `storage_encrypted = false` | Data-at-rest unencrypted — common compliance failure (ISO 27001 A.10.1) | `rds_storage_encrypted` | High | | `enable_misconfig_06 = false` — note: forces DB replacement |
| MC-07 | IAM | Person C | IAM access key created, simulating unrotated key | Maps to CIS "ensure access keys rotated every 90 days" | `iam_rotate_access_key_90_days` | Medium | | `enable_misconfig_07 = false` |
| MC-08 | IAM | Person C | Inline policy `Action:* Resource:*` on service account | Least-privilege violation — effectively grants admin | `iam_policy_allows_privilege_escalation` (or custom) | Critical | | `enable_misconfig_08 = false` |
| MC-09 | Logging | Person C | CloudTrail disabled | "We had no idea what happened" — #1 reason breach investigations fail | `cloudtrail_multi_region_enabled` | Critical | | `enable_misconfig_09 = false` |
| MC-10 | Logging | Person D | VPC Flow Logs disabled | No record of network traffic in/out of VPC | `vpc_flow_logs_enabled` | Medium | | `enable_misconfig_10 = false` |
| MC-11 | Networking | Person D | RDS `publicly_accessible = true` | DB reachable directly from internet, bypassing app tier entirely | `rds_instance_no_public_access` | Critical | | `enable_misconfig_11 = false` — forces DB replacement |
| MC-12 | Encryption | Person D | Default encryption disabled on log bucket | Logs themselves become an unencrypted data-at-rest risk | `s3_bucket_default_encryption` | Medium | | `enable_misconfig_12 = false` |

## Honest caveats to disclose in your report

- **MC-07**: Prowler's key-rotation check is time-gated — a freshly created key will not trigger
  the 90-day-old finding immediately. Document this as a simulated/accelerated finding, and
  explain in your report what the real check looks for.
- **MC-06 and MC-11**: `storage_encrypted` and `publicly_accessible` cannot be toggled in-place
  on an existing RDS instance — Terraform will destroy and recreate the DB (5–10 min each).
  Schedule these two together to minimize total wait time.
- Prowler scans your **entire AWS account**, not just CloudGuardian resources. Filter your
  final report to only the findings relevant to resources tagged `Project = CloudGuardian`.

## Evidence workflow (for whoever is running the demo)

1. Baseline scan (`findings/baseline/`) — everything above should show PASS.
2. For each misconfig, in order: flip flag → `terraform plan` (read the diff, screenshot it) →
   `terraform apply` → screenshot AWS console state → note timestamp here.
3. Post-misconfig scan (`findings/post-misconfig/`) — confirm all 12 show FAIL.
4. Fill in the Evidence column above before the oral defense — a table alone will not survive
   questioning; you need the actual scan excerpt or screenshot for each row.
