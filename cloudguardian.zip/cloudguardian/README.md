# CloudGuardian — AI-Driven Cloud Misconfiguration Detection and Remediation

IIT Roorkee × Futurense — PG Certificate in AI/GenAI Powered Cybersecurity
Capstone Project (CAP-CSE-3W) — Team of 4, AWS-only track

## Team roles (recommended)

| Person | Owns | Misconfigs |
|---|---|---|
| A — Network & Compute | `network.tf`, `security_groups.tf`, `compute.tf` | MC-01, MC-02, MC-03 |
| B — Data & Storage | `database.tf`, `storage.tf` | MC-04, MC-05, MC-06 |
| C — IAM & Logging | `iam.tf`, `logging.tf` | MC-07, MC-08, MC-09 |
| D — Scanning & Integration | Prowler scans, merges Terraform, owns catalogue + report | MC-10, MC-11, MC-12 + consolidation |

## Repo structure (mandatory)

```
cloudguardian/
├── README.md
├── terraform/                     # Week 1: clean + toggle-based misconfig infra
│   ├── providers.tf
│   ├── variables.tf
│   ├── network.tf                 # VPC, subnets, IGW, route tables       (Person A)
│   ├── security_groups.tf         # SGs for web + db tiers                (Person A)
│   ├── compute.tf                 # EC2 web tier + IAM instance role      (Person A)
│   ├── database.tf                # RDS MySQL                             (Person B)
│   ├── storage.tf                 # S3 app bucket + log bucket            (Person B)
│   ├── iam.tf                     # IAM users/roles/keys                  (Person C)
│   ├── logging.tf                 # CloudTrail + VPC Flow Logs            (Person C)
│   ├── outputs.tf
│   ├── terraform.tfvars.example
│   └── .gitignore
├── misconfigs/
│   └── misconfig_catalogue.md     # All 12+ misconfigs, rationale, revert steps
├── findings/
│   ├── baseline/                  # Prowler output BEFORE misconfigs
│   └── post-misconfig/            # Prowler output AFTER misconfigs
├── prioritization/                 # Week 2
│   ├── normalize_findings.py
│   ├── prioritization_model.py
│   ├── llm_remediation.py
│   └── prompts/remediation_prompt_template.md
├── remediation/                    # Week 3
│   ├── lambda_s3_public_access_block.py
│   ├── lambda_rotate_iam_key.py
│   ├── lambda_enable_rds_encryption_flag.py
│   ├── lambda_enable_flow_logs.py
│   ├── remediation_infra.tf
│   └── approval_gate.py
├── compliance/
│   └── compliance_crosswalk.md     # ISO 27001 + DPDP 2023
└── report/
    └── report_outline.md
```

## Execution order — do not skip ahead

```
Week 1: Deploy clean → validate clean → Prowler baseline scan →
        toggle misconfigs ON one at a time → Prowler post-misconfig scan →
        write misconfig catalogue

Week 2: Normalize Prowler findings (CSV/JSON) → prioritization scoring →
        LLM plain-English explanations (verified against raw findings)

Week 3: Build 4 Lambda auto-remediations + human-approval gate →
        compliance crosswalk (ISO 27001 + DPDP) → final report + demo recording
```

## Before anyone touches Terraform

1. One shared AWS account (not four separate accounts) — Prowler needs to scan one consistent account.
2. Each person gets their own IAM user (console + CLI keys) — never share root credentials.
3. Set a **zero-spend budget alarm**: Billing → Budgets → Zero spend budget template.
4. Install per machine: `awscli`, `terraform`, `prowler` (`pip3 install prowler`).
5. Agree on a region — `ap-south-1` (Mumbai) unless your instructor specifies otherwise.
6. Run `aws sts get-caller-identity` on every machine before writing any Terraform — this is your gate.

## How the misconfig toggles work

Every misconfiguration is a **boolean variable** in `terraform.tfvars` (e.g. `enable_misconfig_01 = false`).
Deploy with everything `false` first (clean state) → scan → flip flags to `true` one at a time → re-apply → re-scan.
This gives you a clean `git diff` of `terraform.tfvars` as literal evidence of what changed and when — this is what
graders and your oral defense will want to see, and it avoids four people editing the same resource blocks directly.
