"""
CloudGuardian - Week 3: Auto-remediation #2
Deactivates a stale/unrotated IAM access key (MC-07).

This is classified as a RISKY fix: deactivating a key that's still in active
use by an application would cause an outage. It goes through the human
approval gate (see approval_gate.py) rather than firing automatically.
"""

import json
import boto3

iam = boto3.client("iam")

SAFE_TO_AUTO_REMEDIATE = False  # Requires human approval — see approval_gate.py


def lambda_handler(event, context):
    """
    This function does NOT deactivate the key directly. It only prepares a
    remediation request and hands it to the approval gate. The actual
    deactivation happens in execute_approved_remediation() below, called only
    after a human approves via the approval workflow.
    """
    user_name = event.get("user_name")
    access_key_id = event.get("access_key_id")

    if not user_name or not access_key_id:
        return {"statusCode": 400, "body": "user_name and access_key_id required"}

    remediation_request = {
        "action": "deactivate_iam_access_key",
        "user_name": user_name,
        "access_key_id": access_key_id,
        "risk_level": "risky",
        "status": "pending_approval",
        "reason": "Access key exceeds rotation policy (90+ days simulated per MC-07)",
    }

    print(json.dumps(remediation_request))
    return remediation_request


def execute_approved_remediation(user_name: str, access_key_id: str) -> dict:
    """Called only by approval_gate.py after explicit human sign-off."""
    iam.update_access_key(UserName=user_name, AccessKeyId=access_key_id, Status="Inactive")
    result = {
        "statusCode": 200,
        "user_name": user_name,
        "access_key_id": access_key_id,
        "action": "access_key_deactivated",
        "approved_by_human": True,
    }
    print(json.dumps(result))
    return result
