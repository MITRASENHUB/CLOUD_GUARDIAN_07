# CloudGuardian - Week 3: Infra for the 4 remediation Lambdas.
# Place this file in your terraform/ directory (or a separate terraform-remediation/
# state if your team prefers to keep Week 1 and Week 3 infra separate).

data "archive_file" "s3_public_access_block_zip" {
  type        = "zip"
  source_file = "${path.module}/lambda_s3_public_access_block.py"
  output_path = "${path.module}/build/lambda_s3_public_access_block.zip"
}

data "archive_file" "rotate_iam_key_zip" {
  type        = "zip"
  source_file = "${path.module}/lambda_rotate_iam_key.py"
  output_path = "${path.module}/build/lambda_rotate_iam_key.zip"
}

data "archive_file" "enable_encryption_zip" {
  type        = "zip"
  source_file = "${path.module}/lambda_enable_rds_encryption_flag.py"
  output_path = "${path.module}/build/lambda_enable_encryption.zip"
}

data "archive_file" "enable_flow_logs_zip" {
  type        = "zip"
  source_file = "${path.module}/lambda_enable_flow_logs.py"
  output_path = "${path.module}/build/lambda_enable_flow_logs.zip"
}

resource "aws_iam_role" "remediation_lambda_role" {
  name = "cloudguardian-remediation-lambda-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
    }]
  })
}

# Scoped narrowly to only the actions each remediation function needs —
# this is itself an example of the least-privilege principle the project
# is trying to teach; don't attach AdministratorAccess to your own fix functions.
resource "aws_iam_role_policy" "remediation_lambda_policy" {
  name = "cloudguardian-remediation-lambda-policy"
  role = aws_iam_role.remediation_lambda_role.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "s3:PutBucketPublicAccessBlock",
          "s3:PutEncryptionConfiguration",
          "s3:GetBucketPublicAccessBlock"
        ]
        Resource = "*"
      },
      {
        Effect   = "Allow"
        Action   = ["iam:UpdateAccessKey", "iam:ListAccessKeys"]
        Resource = "*"
      },
      {
        Effect   = "Allow"
        Action   = ["ec2:CreateFlowLogs", "ec2:DescribeFlowLogs"]
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "logs:CreateLogGroup",
          "logs:CreateLogStream",
          "logs:PutLogEvents"
        ]
        Resource = "arn:aws:logs:*:*:*"
      }
    ]
  })
}

resource "aws_lambda_function" "s3_public_access_block" {
  function_name    = "cloudguardian-fix-s3-public-access-block"
  filename         = data.archive_file.s3_public_access_block_zip.output_path
  source_code_hash = data.archive_file.s3_public_access_block_zip.output_base64sha256
  handler          = "lambda_s3_public_access_block.lambda_handler"
  runtime          = "python3.12"
  role             = aws_iam_role.remediation_lambda_role.arn
  timeout          = 30
}

resource "aws_lambda_function" "rotate_iam_key" {
  function_name    = "cloudguardian-fix-rotate-iam-key"
  filename         = data.archive_file.rotate_iam_key_zip.output_path
  source_code_hash = data.archive_file.rotate_iam_key_zip.output_base64sha256
  handler          = "lambda_rotate_iam_key.lambda_handler"
  runtime          = "python3.12"
  role             = aws_iam_role.remediation_lambda_role.arn
  timeout          = 30
}

resource "aws_lambda_function" "enable_encryption" {
  function_name    = "cloudguardian-fix-enable-encryption"
  filename         = data.archive_file.enable_encryption_zip.output_path
  source_code_hash = data.archive_file.enable_encryption_zip.output_base64sha256
  handler          = "lambda_enable_rds_encryption_flag.lambda_handler"
  runtime          = "python3.12"
  role             = aws_iam_role.remediation_lambda_role.arn
  timeout          = 30
}

resource "aws_lambda_function" "enable_flow_logs" {
  function_name    = "cloudguardian-fix-enable-flow-logs"
  filename         = data.archive_file.enable_flow_logs_zip.output_path
  source_code_hash = data.archive_file.enable_flow_logs_zip.output_base64sha256
  handler          = "lambda_enable_flow_logs.lambda_handler"
  runtime          = "python3.12"
  role             = aws_iam_role.remediation_lambda_role.arn
  timeout          = 30

  environment {
    variables = {
      FLOW_LOGS_LOG_GROUP_ARN = "" # fill in from terraform/logging.tf output
      FLOW_LOGS_ROLE_ARN      = "" # fill in from terraform/logging.tf output
    }
  }
}

# NOTE: aws_iam_role.remediation_lambda_role requires the `archive` provider
# too — add this to your providers.tf:
#   archive = { source = "hashicorp/archive", version = "~> 2.4" }
