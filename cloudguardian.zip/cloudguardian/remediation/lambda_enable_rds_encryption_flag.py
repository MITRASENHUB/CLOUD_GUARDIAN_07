"""
CloudGuardian - Week 3: Auto-remediation #3
Enables default AES256 encryption on an S3 bucket missing it (MC-12).

Named "rds_encryption_flag" in the brief's spirit but implemented here for S3,
since RDS storage_encrypted cannot be changed in-place on a running instance
(AWS limitation - would require snapshot + restore to an encrypted copy).
This is documented explicitly in the compliance crosswalk and report: the
lab demonstrates the guardrail/approval-gate PATTERN using an S3 finding,
and separately documents the RDS case as a "planned, snapshot-based fix"
that is too disruptive to auto-remediate live.

Classified as SAFE: enabling default encryption doesn't affect already
existing unencrypted objects and doesn't break read access.
"""

import json
import boto3

s3 = boto3.client("s3")

SAFE_TO_AUTO_REMEDIATE = True


def lambda_handler(event, context):
    bucket_name = event.get("bucket_name")
    if not bucket_name:
        return {"statusCode": 400, "body": "bucket_name required"}

    try:
        s3.put_bucket_encryption(
            Bucket=bucket_name,
            ServerSideEncryptionConfiguration={
                "Rules": [{"ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}}]
            },
        )
        result = {
            "statusCode": 200,
            "bucket": bucket_name,
            "action": "default_encryption_enabled",
            "human_approval_required": False,
        }
        print(json.dumps(result))
        return result
    except Exception as e:
        error_result = {"statusCode": 500, "bucket": bucket_name, "error": str(e)}
        print(json.dumps(error_result))
        return error_result
