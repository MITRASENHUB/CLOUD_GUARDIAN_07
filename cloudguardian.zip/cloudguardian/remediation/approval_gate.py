"""
CloudGuardian - Week 3: Human-approval gate for RISKY remediations.

Design: findings are split into two lanes.

  SAFE lane  -> auto-remediate immediately (S3 public access block, S3
                default encryption, VPC Flow Logs — all purely additive
                or clearly non-disruptive fixes)

  RISKY lane -> queued here, a human must explicitly approve before the
                actual remediation Lambda executes (IAM key deactivation,
                anything that could break a live application: SG rule
                removal, RDS changes, etc.)

For the capstone demo, this is implemented as a simple CLI approval queue
backed by a local JSON file (or DynamoDB if you want to go further — noted
as a stretch goal). In a real environment this would be a Slack/email
approval workflow via SNS, but that's out of scope for a 3-week capstone.
"""

import json
import os

QUEUE_FILE = "pending_approvals.json"


def load_queue() -> list:
    if not os.path.exists(QUEUE_FILE):
        return []
    with open(QUEUE_FILE, "r") as f:
        return json.load(f)


def save_queue(queue: list):
    with open(QUEUE_FILE, "w") as f:
        json.dump(queue, f, indent=2)


def enqueue_remediation(remediation_request: dict):
    queue = load_queue()
    queue.append(remediation_request)
    save_queue(queue)
    print(f"Queued for approval: {remediation_request['action']} on {remediation_request.get('user_name') or remediation_request.get('resource_id')}")


def list_pending():
    queue = load_queue()
    pending = [r for r in queue if r.get("status") == "pending_approval"]
    for i, r in enumerate(pending):
        print(f"[{i}] {r['action']} - {r.get('reason', '')}")
    return pending


def approve(index: int):
    """
    Marks a queued item as approved and dispatches it to the relevant
    remediation function's execute_approved_remediation().
    """
    queue = load_queue()
    pending = [r for r in queue if r.get("status") == "pending_approval"]
    if index >= len(pending):
        print("Invalid index")
        return

    item = pending[index]
    item["status"] = "approved"
    save_queue(queue)

    if item["action"] == "deactivate_iam_access_key":
        from lambda_rotate_iam_key import execute_approved_remediation
        result = execute_approved_remediation(item["user_name"], item["access_key_id"])
        print(f"Executed: {result}")
    else:
        print(f"No executor wired up for action: {item['action']}")


def reject(index: int, reason: str = ""):
    queue = load_queue()
    pending = [r for r in queue if r.get("status") == "pending_approval"]
    if index >= len(pending):
        print("Invalid index")
        return
    pending[index]["status"] = "rejected"
    pending[index]["rejection_reason"] = reason
    save_queue(queue)
    print(f"Rejected: {pending[index]['action']}")


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python3 approval_gate.py [list|approve <i>|reject <i> <reason>]")
        sys.exit(0)

    cmd = sys.argv[1]
    if cmd == "list":
        list_pending()
    elif cmd == "approve":
        approve(int(sys.argv[2]))
    elif cmd == "reject":
        reject(int(sys.argv[2]), sys.argv[3] if len(sys.argv) > 3 else "")
