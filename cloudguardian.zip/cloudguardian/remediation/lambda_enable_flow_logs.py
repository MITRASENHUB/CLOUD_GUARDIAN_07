"""
CloudGuardian - Week 3: Auto-remediation #4
Re-enables VPC Flow Logs for a VPC found without them (MC-10).

Classified as SAFE: enabling flow logs is purely additive observability,
cannot break any existing application traffic.
"""

import json
import os
import boto3

ec2 = boto3.client("ec2")

SAFE_TO_AUTO_REMEDIATE = True

# These should be set as Lambda environment variables, pointing at the
# CloudWatch Log Group and IAM role created in terraform/logging.tf
LOG_GROUP_ARN = os.environ.get("FLOW_LOGS_LOG_GROUP_ARN", "")
FLOW_LOGS_ROLE_ARN = os.environ.get("FLOW_LOGS_ROLE_ARN", "")


def lambda_handler(event, context):
    vpc_id = event.get("vpc_id")
    if not vpc_id:
        return {"statusCode": 400, "body": "vpc_id required"}

    if not LOG_GROUP_ARN or not FLOW_LOGS_ROLE_ARN:
        return {"statusCode": 500, "body": "Lambda missing required env vars"}

    try:
        response = ec2.create_flow_logs(
            ResourceIds=[vpc_id],
            ResourceType="VPC",
            TrafficType="ALL",
            LogDestinationType="cloud-watch-logs",
            LogGroupName=LOG_GROUP_ARN.split(":")[-1],
            DeliverLogsPermissionArn=FLOW_LOGS_ROLE_ARN,
        )
        result = {
            "statusCode": 200,
            "vpc_id": vpc_id,
            "action": "flow_logs_enabled",
            "flow_log_ids": response.get("FlowLogIds", []),
            "human_approval_required": False,
        }
        print(json.dumps(result))
        return result
    except Exception as e:
        error_result = {"statusCode": 500, "vpc_id": vpc_id, "error": str(e)}
        print(json.dumps(error_result))
        return error_result
