"""
CloudGuardian - Week 3: Safe auto-remediation #1
Re-enables S3 Public Access Block on a bucket found to have it disabled (MC-04).

This is classified as a SAFE fix: turning public access block back on cannot
break application functionality that depended on being publicly readable,
because nothing in this lab is meant to be public in the first place.

Triggered by: Security Hub / EventBridge finding, or manual invocation with a
bucket name for testing.
"""

import json
import boto3

s3 = boto3.client("s3")

SAFE_TO_AUTO_REMEDIATE = True  # This fix never requires human approval


def lambda_handler(event, context):
    bucket_name = extract_bucket_name(event)

    if not bucket_name:
        return {"statusCode": 400, "body": "No bucket name found in event"}

    try:
        s3.put_public_access_block(
            Bucket=bucket_name,
            PublicAccessBlockConfiguration={
                "BlockPublicAcls": True,
                "IgnorePublicAcls": True,
                "BlockPublicPolicy": True,
                "RestrictPublicBuckets": True,
            },
        )
        result = {
            "statusCode": 200,
            "bucket": bucket_name,
            "action": "public_access_block_enabled",
            "human_approval_required": False,
        }
        print(json.dumps(result))
        return result

    except Exception as e:
        error_result = {"statusCode": 500, "bucket": bucket_name, "error": str(e)}
        print(json.dumps(error_result))
        return error_result


def extract_bucket_name(event: dict) -> str:
    """
    Supports both a direct test invocation ({"bucket_name": "..."}) and a
    Security Hub finding event shape.
    """
    if "bucket_name" in event:
        return event["bucket_name"]

    try:
        finding = event["detail"]["findings"][0]
        resource_id = finding["Resources"][0]["Id"]
        # Security Hub ARNs look like arn:aws:s3:::bucket-name
        return resource_id.split(":::")[-1]
    except (KeyError, IndexError):
        return ""
