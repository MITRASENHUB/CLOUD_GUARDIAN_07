# CloudGuardian Final Report — Outline (14-18 pages, team of 4)

1. **Executive Summary** (0.5 page) — problem statement, what you built, key results
2. **Architecture** (1.5-2 pages) — 3-tier diagram, why EC2+RDS+S3, region choice, shared-responsibility model
3. **Misconfiguration Catalogue** (2-3 pages) — table from `misconfigs/misconfig_catalogue.md`, with screenshots
4. **Detection Methodology** (2 pages) — Prowler setup, baseline vs post-misconfig scan comparison
5. **Prioritization Model** (2 pages) — feature justification (CVSS proxy x exposure x blast radius), scoring table, honest evaluation of where the model gets it wrong
6. **LLM Remediation Guidance** (1.5 pages) — prompt template, disclosure of model used, verification methodology and results
7. **Auto-Remediation & Guardrails** (2 pages) — the 4 Lambda functions, safe vs risky classification rationale, human-approval gate walkthrough
8. **Compliance Mapping** (1.5 pages) — crosswalk table, discussion of safeguard vs direct-compliance distinction
9. **Ethics & Responsible Use** (0.5 page) — confirm lab-only scope, credential handling, disclosure statement
10. **Conclusion & Lessons Learned** (1 page) — what would you do differently, what surprised you
11. **Appendix** — full Terraform (or link to repo), full Prowler outputs (or link), team role breakdown

## Demo recording checklist (end-to-end: detect → prioritize → remediate)

- [ ] Show baseline Prowler scan (mostly PASS)
- [ ] Show one misconfig being toggled on and applied
- [ ] Show post-misconfig Prowler scan catching it
- [ ] Show the finding flowing through `normalize_findings.py` → `prioritization_model.py`
- [ ] Show an LLM explanation being generated and its verification note
- [ ] Show a SAFE remediation firing automatically
- [ ] Show a RISKY remediation being queued, then approved via `approval_gate.py`
- [ ] Show `terraform destroy` at the end (cost hygiene, mention this in the report too)
