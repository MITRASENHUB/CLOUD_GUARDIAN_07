# Owned by: Person C (IAM & Logging)
# Misconfigs: MC-07 (stale/unrotated access key), MC-08 (overly broad inline policy)

# A secondary IAM user representing a "service account" used to demonstrate
# key-rotation and least-privilege findings, separate from your personal
# console/CLI IAM users.
resource "aws_iam_user" "service_account" {
  name = "${var.project_name}-service-account"
  tags = { Name = "${var.project_name}-service-account" }
}

# MC-07: create an access key for this user. Prowler's key-rotation check
# looks at key age (commonly 90+ days) — a brand-new key will NOT trigger it
# immediately. Document this honestly in your catalogue: either (a) tag the
# finding as "simulated" and explain the real check in your report, or
# (b) if your program allows it, manually age the key by adjusting the
# reported creation context in your writeup rather than faking AWS metadata.
resource "aws_iam_access_key" "service_account_key" {
  count = var.enable_misconfig_07 ? 1 : 0
  user  = aws_iam_user.service_account.name
}

# CLEAN state: this user has no permissions attached until the app needs them.
# MC-08: attach an inline policy granting Action:* Resource:* — an overly
# broad, effectively-admin policy. Classic least-privilege violation Prowler
# and CIS benchmarks flag directly.
resource "aws_iam_user_policy" "misconfig_08_overly_broad" {
  count = var.enable_misconfig_08 ? 1 : 0
  name  = "${var.project_name}-overly-broad-policy"
  user  = aws_iam_user.service_account.name

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "*"
      Resource = "*"
    }]
  })
}
