output "web_instance_public_ip" {
  value = aws_instance.web.public_ip
}

output "db_endpoint" {
  value = aws_db_instance.main.endpoint
}

output "app_bucket_name" {
  value = aws_s3_bucket.app_bucket.bucket
}

output "log_bucket_name" {
  value = aws_s3_bucket.log_bucket.bucket
}

output "service_account_access_key_id" {
  value     = var.enable_misconfig_07 ? aws_iam_access_key.service_account_key[0].id : "MC-07 disabled — no key created"
  sensitive = true
}

output "active_misconfigs" {
  description = "Quick summary of which misconfigs are currently toggled on — check this before every Prowler scan"
  value = {
    MC01_open_ssh              = var.enable_misconfig_01
    MC02_open_db_port          = var.enable_misconfig_02
    MC03_admin_ec2_role        = var.enable_misconfig_03
    MC04_s3_public_access_off  = var.enable_misconfig_04
    MC05_s3_public_bucket_pol  = var.enable_misconfig_05
    MC06_rds_encryption_off    = var.enable_misconfig_06
    MC07_stale_access_key      = var.enable_misconfig_07
    MC08_overly_broad_iam      = var.enable_misconfig_08
    MC09_cloudtrail_disabled   = var.enable_misconfig_09
    MC10_flow_logs_disabled    = var.enable_misconfig_10
    MC11_rds_publicly_accessible = var.enable_misconfig_11
    MC12_log_bucket_encryption_off = var.enable_misconfig_12
  }
}
