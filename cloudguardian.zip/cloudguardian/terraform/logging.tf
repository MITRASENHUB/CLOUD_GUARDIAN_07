# Owned by: Person C (IAM & Logging)
# Misconfigs: MC-09 (CloudTrail disabled), MC-10 (VPC Flow Logs disabled)

# MC-09: CloudTrail is conditionally created — when the misconfig is "on",
# we simply don't create it. This is the #1 reason breach investigations
# fail: "we had no idea what happened."
resource "aws_cloudtrail" "main" {
  count                         = var.enable_misconfig_09 ? 0 : 1
  name                          = "${var.project_name}-trail"
  s3_bucket_name                = aws_s3_bucket.log_bucket.id
  s3_key_prefix                 = "cloudtrail"
  include_global_service_events = true
  is_multi_region_trail         = true
  enable_log_file_validation    = true

  depends_on = [aws_s3_bucket_policy.log_bucket_policy]
}

# IAM role that lets the VPC Flow Logs service publish into CloudWatch Logs
resource "aws_iam_role" "flow_logs_role" {
  name = "${var.project_name}-flow-logs-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "vpc-flow-logs.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy" "flow_logs_policy" {
  name = "${var.project_name}-flow-logs-policy"
  role = aws_iam_role.flow_logs_role.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents",
        "logs:DescribeLogGroups",
        "logs:DescribeLogStreams"
      ]
      Resource = "*"
    }]
  })
}

resource "aws_cloudwatch_log_group" "flow_logs" {
  name              = "/cloudguardian/vpc-flow-logs"
  retention_in_days = 7
}

# MC-10: VPC Flow Logs conditionally created — when the misconfig is "on",
# we don't create it, so there's no record of network traffic in/out of the VPC.
resource "aws_flow_log" "main" {
  count           = var.enable_misconfig_10 ? 0 : 1
  vpc_id          = aws_vpc.main.id
  traffic_type    = "ALL"
  log_destination = aws_cloudwatch_log_group.flow_logs.arn
  iam_role_arn    = aws_iam_role.flow_logs_role.arn
}
