# Owned by: Person B (Data & Storage)
# Misconfigs: MC-04 (public access block off), MC-05 (public bucket policy), MC-12 (log bucket encryption off)

resource "random_id" "bucket_suffix" {
  byte_length = 4
}

# --- App bucket ---
resource "aws_s3_bucket" "app_bucket" {
  bucket = "${var.project_name}-app-${random_id.bucket_suffix.hex}"
  tags   = { Name = "${var.project_name}-app-bucket" }
}

# CLEAN state: all four public access block settings TRUE (fully locked down).
# MC-04: when enabled, block_public_acls/policy flip to false, opening the door
# for MC-05's public bucket policy to actually take effect.
resource "aws_s3_bucket_public_access_block" "app_bucket" {
  bucket = aws_s3_bucket.app_bucket.id

  block_public_acls       = var.enable_misconfig_04 ? false : true
  block_public_policy     = var.enable_misconfig_04 ? false : true
  ignore_public_acls      = var.enable_misconfig_04 ? false : true
  restrict_public_buckets = var.enable_misconfig_04 ? false : true
}

# MC-05: bucket policy allowing s3:GetObject to * — makes the bucket actually
# publicly readable, not just technically allowed. Only takes effect once
# MC-04 has also removed the public access block.
resource "aws_s3_bucket_policy" "app_bucket_public_read" {
  count  = var.enable_misconfig_05 ? 1 : 0
  bucket = aws_s3_bucket.app_bucket.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid       = "PublicReadMisconfig05"
      Effect    = "Allow"
      Principal = "*"
      Action    = "s3:GetObject"
      Resource  = "${aws_s3_bucket.app_bucket.arn}/*"
    }]
  })

  depends_on = [aws_s3_bucket_public_access_block.app_bucket]
}

resource "aws_s3_bucket_server_side_encryption_configuration" "app_bucket" {
  bucket = aws_s3_bucket.app_bucket.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

# --- Log bucket ---
resource "aws_s3_bucket" "log_bucket" {
  bucket = "${var.project_name}-logs-${random_id.bucket_suffix.hex}"
  tags   = { Name = "${var.project_name}-log-bucket" }
}

resource "aws_s3_bucket_public_access_block" "log_bucket" {
  bucket                  = aws_s3_bucket.log_bucket.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# MC-12: disable default encryption on the log bucket. Modeled as conditional
# creation of the encryption config resource — when the misconfig is "on", we
# simply don't create it, so the bucket falls back to unencrypted-by-default.
resource "aws_s3_bucket_server_side_encryption_configuration" "log_bucket" {
  count  = var.enable_misconfig_12 ? 0 : 1
  bucket = aws_s3_bucket.log_bucket.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

# Bucket policy allowing CloudTrail and VPC Flow Logs to write here
resource "aws_s3_bucket_policy" "log_bucket_policy" {
  bucket = aws_s3_bucket.log_bucket.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "AWSCloudTrailAclCheck"
        Effect    = "Allow"
        Principal = { Service = "cloudtrail.amazonaws.com" }
        Action    = "s3:GetBucketAcl"
        Resource  = aws_s3_bucket.log_bucket.arn
      },
      {
        Sid       = "AWSCloudTrailWrite"
        Effect    = "Allow"
        Principal = { Service = "cloudtrail.amazonaws.com" }
        Action    = "s3:PutObject"
        Resource  = "${aws_s3_bucket.log_bucket.arn}/cloudtrail/AWSLogs/*"
        Condition = { StringEquals = { "s3:x-amz-acl" = "bucket-owner-full-control" } }
      },
      {
        Sid       = "AWSFlowLogsWrite"
        Effect    = "Allow"
        Principal = { Service = "delivery.logs.amazonaws.com" }
        Action    = "s3:PutObject"
        Resource  = "${aws_s3_bucket.log_bucket.arn}/vpc-flow-logs/*"
        Condition = { StringEquals = { "s3:x-amz-acl" = "bucket-owner-full-control" } }
      }
    ]
  })
}
