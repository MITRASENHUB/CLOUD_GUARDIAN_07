# Owned by: Person A (Network & Compute)
# Misconfigs: MC-01 (open SSH), MC-02 (open DB port)

resource "aws_security_group" "web" {
  name        = "${var.project_name}-web-sg"
  description = "Security group for the web tier EC2 instance"
  vpc_id      = aws_vpc.main.id

  # CLEAN state: SSH only from your own IP.
  # MC-01: when enabled, SSH opens to the whole internet — the single most
  # common "internet scanner finds you in minutes" misconfig.
  ingress {
    description = "SSH"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = var.enable_misconfig_01 ? ["0.0.0.0/0"] : [var.your_ip_cidr]
  }

  ingress {
    description = "HTTP"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${var.project_name}-web-sg" }
}

resource "aws_security_group" "db" {
  name        = "${var.project_name}-db-sg"
  description = "Security group for the RDS database tier"
  vpc_id      = aws_vpc.main.id

  # CLEAN state: MySQL only reachable from the web tier's security group.
  # MC-02: when enabled, DB port opens to the whole internet — breaks tier
  # isolation, the DB becomes directly reachable without going through the app.
  dynamic "ingress" {
    for_each = var.enable_misconfig_02 ? [1] : []
    content {
      description = "MySQL - MISCONFIGURED: open to internet"
      from_port   = 3306
      to_port     = 3306
      protocol    = "tcp"
      cidr_blocks = ["0.0.0.0/0"]
    }
  }

  dynamic "ingress" {
    for_each = var.enable_misconfig_02 ? [] : [1]
    content {
      description     = "MySQL - web tier only (clean)"
      from_port       = 3306
      to_port         = 3306
      protocol        = "tcp"
      security_groups = [aws_security_group.web.id]
    }
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${var.project_name}-db-sg" }
}
