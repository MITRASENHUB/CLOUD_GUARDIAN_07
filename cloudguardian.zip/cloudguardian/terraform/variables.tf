variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
  default     = "ap-south-1"
}

variable "project_name" {
  description = "Short name used as a prefix on all resources"
  type        = string
  default     = "cloudguardian"
}

variable "your_ip_cidr" {
  description = "Your public IP in CIDR form, e.g. 49.36.x.x/32 (get it from https://checkip.amazonaws.com). Used for the SSH allow-list in the CLEAN state."
  type        = string
}

variable "vpc_cidr" {
  type    = string
  default = "10.0.0.0/16"
}

variable "public_subnet_cidr" {
  type    = string
  default = "10.0.1.0/24"
}

variable "private_subnet_cidr" {
  type    = string
  default = "10.0.2.0/24"
}

variable "private_subnet_2_cidr" {
  description = "RDS requires a subnet group spanning 2 AZs even for a single instance"
  type        = string
  default     = "10.0.3.0/24"
}

variable "availability_zones" {
  type    = list(string)
  default = ["ap-south-1a", "ap-south-1b"]
}

variable "instance_type" {
  type    = string
  default = "t2.micro" # Free Tier eligible
}

variable "db_instance_class" {
  type    = string
  default = "db.t3.micro" # Free Tier eligible
}

variable "db_username" {
  type    = string
  default = "cgadmin"
}

variable "db_password" {
  description = "Set via terraform.tfvars (gitignored). Min 8 chars."
  type        = string
  sensitive   = true
}

# ---------------------------------------------------------------------------
# MISCONFIG TOGGLES — all default to false (CLEAN state).
# Flip to true ONE AT A TIME during the "break it" phase of Week 1.
# Owner column shows who is responsible for demoing / documenting each one.
# ---------------------------------------------------------------------------

# --- Networking (Person A) ---
variable "enable_misconfig_01" {
  description = "MC-01: Open SSH (port 22) to 0.0.0.0/0 on the web security group"
  type        = bool
  default     = false
}

variable "enable_misconfig_02" {
  description = "MC-02: Open DB port 3306 to 0.0.0.0/0 instead of web-tier-only"
  type        = bool
  default     = false
}

variable "enable_misconfig_03" {
  description = "MC-03: Attach AdministratorAccess to the EC2 web instance role (over-privileged IAM)"
  type        = bool
  default     = false
}

# --- Storage (Person B) ---
variable "enable_misconfig_04" {
  description = "MC-04: Disable S3 Public Access Block on the app bucket"
  type        = bool
  default     = false
}

variable "enable_misconfig_05" {
  description = "MC-05: Attach a bucket policy allowing s3:GetObject to * (public read)"
  type        = bool
  default     = false
}

variable "enable_misconfig_06" {
  description = "MC-06: Disable RDS storage encryption (storage_encrypted = false). NOTE: forces replacement, takes 5-10 min."
  type        = bool
  default     = false
}

# --- IAM & Logging (Person C) ---
variable "enable_misconfig_07" {
  description = "MC-07: Create an IAM access key intentionally left unrotated (tagged old-creation-date for the report narrative)"
  type        = bool
  default     = false
}

variable "enable_misconfig_08" {
  description = "MC-08: Attach an overly broad inline IAM policy (Action: * , Resource: *) to a secondary IAM role"
  type        = bool
  default     = false
}

variable "enable_misconfig_09" {
  description = "MC-09: Disable CloudTrail logging"
  type        = bool
  default     = false
}

# --- Additional / cross-cutting (Person D, pick 3 to reach 12+) ---
variable "enable_misconfig_10" {
  description = "MC-10: Disable VPC Flow Logs"
  type        = bool
  default     = false
}

variable "enable_misconfig_11" {
  description = "MC-11: RDS publicly_accessible = true (DB directly reachable from internet, breaks tier isolation)"
  type        = bool
  default     = false
}

variable "enable_misconfig_12" {
  description = "MC-12: Disable default encryption on the S3 log bucket"
  type        = bool
  default     = false
}
