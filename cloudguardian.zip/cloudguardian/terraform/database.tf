# Owned by: Person B (Data & Storage)
# Misconfigs: MC-06 (encryption disabled), MC-11 (publicly accessible)

resource "aws_db_instance" "main" {
  identifier     = "${var.project_name}-db"
  engine         = "mysql"
  engine_version = "8.0"
  instance_class = var.db_instance_class

  allocated_storage = 20 # Free Tier limit
  storage_type       = "gp2"

  db_name  = "cloudguardian"
  username = var.db_username
  password = var.db_password

  db_subnet_group_name   = aws_db_subnet_group.main.name
  vpc_security_group_ids = [aws_security_group.db.id]

  # MC-06: encryption disabled. NOTE: storage_encrypted cannot be toggled
  # in-place on an existing RDS instance — changing it forces Terraform to
  # destroy and recreate the DB (5-10 min). Plan your misconfig order so this
  # happens once, deliberately, not interleaved with quick changes.
  storage_encrypted = var.enable_misconfig_06 ? false : true

  # MC-11: DB directly reachable from the internet, breaking tier isolation.
  # This ALSO forces a replacement when toggled.
  publicly_accessible = var.enable_misconfig_11 ? true : false

  skip_final_snapshot       = true
  final_snapshot_identifier = null
  backup_retention_period   = 0 # keep Free Tier costs at zero; note in report as a real tradeoff

  tags = { Name = "${var.project_name}-db" }
}
