# Owned by: Person A (Network & Compute)
# Misconfigs: MC-03 (over-privileged EC2 IAM role)

data "aws_ami" "amazon_linux" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-*-x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

# CLEAN state: least-privilege role, only allowed to read its own app S3 bucket.
resource "aws_iam_role" "web_instance_role" {
  name = "${var.project_name}-web-instance-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "ec2.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy" "web_least_privilege" {
  name = "${var.project_name}-web-least-privilege"
  role = aws_iam_role.web_instance_role.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["s3:GetObject", "s3:PutObject"]
      Resource = "${aws_s3_bucket.app_bucket.arn}/*"
    }]
  })
}

# MC-03: attach full AdministratorAccess to the same role — a classic
# over-privileged role. If the web app is compromised, attacker gets the
# whole AWS account, not just the app bucket.
resource "aws_iam_role_policy_attachment" "misconfig_03_admin_access" {
  count      = var.enable_misconfig_03 ? 1 : 0
  role       = aws_iam_role.web_instance_role.name
  policy_arn = "arn:aws:iam::aws:policy/AdministratorAccess"
}

resource "aws_iam_instance_profile" "web" {
  name = "${var.project_name}-web-instance-profile"
  role = aws_iam_role.web_instance_role.name
}

resource "aws_instance" "web" {
  ami                    = data.aws_ami.amazon_linux.id
  instance_type          = var.instance_type
  subnet_id              = aws_subnet.public.id
  vpc_security_group_ids = [aws_security_group.web.id]
  iam_instance_profile   = aws_iam_instance_profile.web.name

  # Enforce IMDSv2 — good practice, prevents SSRF-to-credential-theft attacks
  metadata_options {
    http_tokens   = "required"
    http_endpoint = "enabled"
  }

  user_data = <<-EOF
    #!/bin/bash
    dnf install -y httpd
    systemctl enable httpd
    systemctl start httpd
    echo "<h1>CloudGuardian Lab Web Tier</h1>" > /var/www/html/index.html
  EOF

  tags = { Name = "${var.project_name}-web" }
}
